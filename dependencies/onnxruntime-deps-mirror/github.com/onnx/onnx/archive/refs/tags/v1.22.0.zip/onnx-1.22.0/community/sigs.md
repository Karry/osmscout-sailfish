<!--
Copyright (c) ONNX Project Contributors

SPDX-License-Identifier: Apache-2.0
-->

# SIGs - Special Interest Groups

As described in the ONNX [governance](/community/readme.md#sig---special-interest-groups), Special Interest Groups (SIGs) are persistent groups responsible for specific parts of the project. SIGs have open and transparent proceedings to develop goals and implement code contributions. SIGs are also responsible for ongoing maintenance of the code in their areas.

## Joining a SIG

If you are interested in participating, please [join the discussion](https://join.slack.com/t/lfaifoundation/shared_invite/zt-3wx5vohc3-MeSYi3_dscb~u~cqs7zlPg) in the respective Slack channels. Details about any upcoming meetings will also be shared in the Slack channels. SIG artifacts can be found in the [sigs repository](https://github.com/onnx/sigs).

You can find the schedule of SIG meetings on the [LFX calendar](https://zoom-lfx.platform.linuxfoundation.org/meetings/lfai-onnx?view=month)

## Current SIGs

The list of current sig is found [here](https://github.com/onnx/sigs#current-sigs).
