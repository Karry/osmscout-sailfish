# SPDX-License-Identifier: Apache-2.0

# Look up a dependency by name in sbom.cdx.json and set URL, SHA256, and VERSION
# variables in the caller's scope. For example:
#   sbom_get_dep("abseil-cpp" _absl)
# sets _absl_URL, _absl_SHA256, _absl_VERSION.
function(sbom_get_dep dep_name prefix)
  file(READ "${CMAKE_CURRENT_SOURCE_DIR}/sbom.cdx.json" _sbom)
  string(JSON _count LENGTH "${_sbom}" "components")
  foreach(_i RANGE 0 ${_count})
    if(_i EQUAL _count)
      break()
    endif()
    string(JSON _name GET "${_sbom}" "components" ${_i} "name")
    if(_name STREQUAL "${dep_name}")
      string(JSON _url GET "${_sbom}" "components" ${_i} "externalReferences" 0 "url")
      string(JSON _version GET "${_sbom}" "components" ${_i} "version")
      set(${prefix}_URL "${_url}" PARENT_SCOPE)
      set(${prefix}_VERSION "${_version}" PARENT_SCOPE)
      # SHA256 is optional (e.g. git-only deps like nanobind).
      string(JSON _hash_count ERROR_VARIABLE _err LENGTH "${_sbom}" "components" ${_i} "hashes")
      if(_hash_count AND _hash_count GREATER 0)
        string(JSON _sha256 GET "${_sbom}" "components" ${_i} "hashes" 0 "content")
        set(${prefix}_SHA256 "${_sha256}" PARENT_SCOPE)
      else()
        set(${prefix}_SHA256 "" PARENT_SCOPE)
      endif()
      return()
    endif()
  endforeach()
  message(FATAL_ERROR "Dependency '${dep_name}' not found in sbom.cdx.json")
endfunction()

# Compiler hardening flags based on OpenSSF guidelines:
# https://best.openssf.org/Compiler-Hardening-Guides/Compiler-Options-Hardening-Guide-for-C-and-C++.html
function(add_onnx_hardening_flags target)
  if(NOT ONNX_HARDENING)
    return()
  endif()

  if(MSVC)
    # MSVC hardening compile flags
    target_compile_options(${target} PRIVATE
      /GS        # Buffer security checks
      /guard:cf  # Control Flow Guard
      /sdl       # Security Development Lifecycle checks
    )
    # MSVC hardening linker flags
    target_link_options(${target} PRIVATE
      /DYNAMICBASE  # ASLR
      /NXCOMPAT     # Data Execution Prevention
      /guard:cf     # Control Flow Guard (linker side)
    )
    # CET shadow stack requires VS 2019 (MSVC 19.20+) and is x86/x64 only
    if(MSVC_VERSION GREATER_EQUAL 1920 AND CMAKE_SYSTEM_PROCESSOR MATCHES "x86|x64|X86|AMD64")
      target_link_options(${target} PRIVATE /CETCOMPAT)
    endif()
  else()
    # GCC/Clang hardening compile flags
    target_compile_options(${target} PRIVATE
      -Wformat
      -Wformat=2
      -Wimplicit-fallthrough
      -Werror=format-security
      -fstack-protector-strong
      -fno-delete-null-pointer-checks
      -fno-strict-overflow
      -fno-strict-aliasing
    )

    # Zero-initialize uninitialized stack variables (requires compiler support)
    include(CheckCXXCompilerFlag)
    check_cxx_compiler_flag(-ftrivial-auto-var-init=zero COMPILER_SUPPORTS_AUTO_VAR_INIT)
    if(COMPILER_SUPPORTS_AUTO_VAR_INIT)
      target_compile_options(${target} PRIVATE -ftrivial-auto-var-init=zero)
    endif()

    # _FORTIFY_SOURCE requires optimization and conflicts with sanitizers
    if(NOT ONNX_USE_ASAN)
      target_compile_options(${target} PRIVATE
        -U_FORTIFY_SOURCE
        -D_FORTIFY_SOURCE=3
      )
    endif()

    # C++ standard library assertions
    target_compile_definitions(${target} PRIVATE _GLIBCXX_ASSERTIONS)

    # Stack clash protection (Linux only - not supported on macOS)
    if(CMAKE_SYSTEM_NAME STREQUAL "Linux")
      include(CheckCXXCompilerFlag)
      check_cxx_compiler_flag(-fstack-clash-protection COMPILER_SUPPORTS_STACK_CLASH)
      if(COMPILER_SUPPORTS_STACK_CLASH)
        target_compile_options(${target} PRIVATE -fstack-clash-protection)
      endif()
    endif()

    # Control-flow protection for x86_64 (Linux only - not supported on macOS)
    if(CMAKE_SYSTEM_NAME STREQUAL "Linux" AND CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|amd64|AMD64")
      include(CheckCXXCompilerFlag)
      check_cxx_compiler_flag(-fcf-protection=full COMPILER_SUPPORTS_CF_PROTECTION)
      if(COMPILER_SUPPORTS_CF_PROTECTION)
        target_compile_options(${target} PRIVATE -fcf-protection=full)
      endif()
    endif()

    # Branch protection for AArch64 (Linux only - macOS uses different mechanism)
    if(CMAKE_SYSTEM_NAME STREQUAL "Linux" AND CMAKE_SYSTEM_PROCESSOR MATCHES "aarch64|arm64|ARM64")
      include(CheckCXXCompilerFlag)
      check_cxx_compiler_flag(-mbranch-protection=standard COMPILER_SUPPORTS_BRANCH_PROTECTION)
      if(COMPILER_SUPPORTS_BRANCH_PROTECTION)
        target_compile_options(${target} PRIVATE -mbranch-protection=standard)
      endif()
    endif()

    # Linker hardening flags (Linux only, not macOS)
    if(CMAKE_SYSTEM_NAME STREQUAL "Linux")
      target_link_options(${target} PRIVATE
        -Wl,-z,noexecstack
        -Wl,-z,relro
        -Wl,-z,now
      )
    endif()
  endif()
endfunction()

# Adjusts the MSVC_RUNTIME_LIBRARY property for a given target.
# If CMAKE_MSVC_RUNTIME_LIBRARY is defined, we assume the user wants to explicitly use that value.
# If not, we respect ONNX_USE_MSVC_STATIC_RUNTIME and delegate to the static/dynamic lib respectively,
# with Debug builds using the debug libs.
function(add_msvc_runtime_flag lib)
  if(DEFINED CMAKE_MSVC_RUNTIME_LIBRARY)
    # Don't do anything here and respect parent-project provided value.
    # CMake will have already associated the default value with our target.
    message(STATUS "Ignoring ONNX_USE_MSVC_STATIC_RUNTIME since CMAKE_MSVC_RUNTIME_LIBRARY is defined.")
  else()
    if(ONNX_USE_MSVC_STATIC_RUNTIME)
      set_target_properties(${lib} PROPERTIES
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>"
      )
    else()
      set_target_properties(${lib} PROPERTIES
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>DLL"
      )
    endif()
  endif()
endfunction()

function(add_onnx_global_defines target)
  target_compile_definitions(${target}
                             PUBLIC "ONNX_NAMESPACE=${ONNX_NAMESPACE}")

  if(ONNX_ML)
    target_compile_definitions(${target} PUBLIC "ONNX_ML=1")
  endif()

  if(ONNX_USE_LITE_PROTO)
    target_compile_definitions(${target} PUBLIC "ONNX_USE_LITE_PROTO=1")
  endif()

  if(ONNX_DISABLE_STATIC_REGISTRATION)
    target_compile_definitions(${target}
                               PUBLIC "__ONNX_DISABLE_STATIC_REGISTRATION")
  endif()
endfunction()

function(add_onnx_compile_options target)
  if(MSVC)
    add_msvc_runtime_flag(${target})
    if(ONNX_WERROR)
      target_compile_options(${target} PRIVATE "/WX")
    endif()
  else()
    target_compile_options(${target} PRIVATE -Wall -Wextra)
    if(CMAKE_COMPILER_IS_GNUCXX AND CMAKE_CXX_COMPILER_VERSION
                                    VERSION_GREATER_EQUAL 13)
      target_compile_options(${target} PRIVATE "-Wno-stringop-overflow")
    endif()
    if(CMAKE_CXX_COMPILER_ID STREQUAL "AppleClang")
      target_compile_options(${target} PRIVATE "-Wno-shorten-64-to-32")
    endif()
    if(ONNX_WERROR)
      target_compile_options(${target} PRIVATE "-Werror")
    endif()
  endif()
  target_include_directories(
    ${target}
    PUBLIC $<BUILD_INTERFACE:${ONNX_ROOT}> $<INSTALL_INTERFACE:include>
           $<BUILD_INTERFACE:${CMAKE_CURRENT_BINARY_DIR}>)
  target_link_libraries(${target} PUBLIC ${LINKED_PROTOBUF_TARGET})
  get_target_property(_onnx_linked_protobuf_is_imported ${LINKED_PROTOBUF_TARGET} IMPORTED)
  foreach(ABSL_USED_TARGET IN LISTS protobuf_ABSL_USED_TARGETS)
    if(TARGET ${ABSL_USED_TARGET})
      target_link_libraries(${target} PUBLIC ${ABSL_USED_TARGET})
      if(NOT _onnx_linked_protobuf_is_imported)
        add_dependencies(${LINKED_PROTOBUF_TARGET} ${ABSL_USED_TARGET})
      endif()
    endif()
  endforeach()
  # Prevent "undefined symbol: _ZNSt10filesystem7__cxx114path14_M_split_cmptsEv"
  # (std::filesystem::__cxx11::path::_M_split_cmpts()) on gcc 8
  if(CMAKE_COMPILER_IS_GNUCXX AND CMAKE_CXX_COMPILER_VERSION VERSION_LESS 9.0)
    target_link_libraries(${target} PRIVATE "-lstdc++fs")
  endif()

  # Apply hardening flags if enabled
  add_onnx_hardening_flags(${target})
endfunction()
